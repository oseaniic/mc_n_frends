Mo Creatures [1.6.4]
------------------------------------------------------------------------------------------------
Mo'creatures mod für Minecraft 1.6.4 fügt hinzu, dass Ihr Spiel Coole neue Tiere und Kreaturen. 

Herunterladen und bewerten die mod Mo Creatures für Minecraft 1.6.4 bitte klicken Sie auf die links unten auf der Seite.

################################################################################################

EINBAUANLEITUNG
------------------------------------------------------------------------------------------------
1. Kopieren von Dateien

(!) Vergessen Sie nicht, machen Kopien des Originals ersetzt Dateien in der Lage sein, um die Änderung zu entfernen!

Kopieren Sie den gesamten Inhalt des Ordners "00 - Copy to game folder" auf den Ordner, in dem das Spiel installiert ist. Bestätigen Sie den Ersatz.

################################################################################################

Diese Modifikation wurde von www.worldofmods.eu heruntergeladen wurden
Permanent Link zu Seite modification`s: https://www.worldofmods.eu/de/minecraft/mods/4582-mo-creatures-164.html

Überprüfen unsere sozialen groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods