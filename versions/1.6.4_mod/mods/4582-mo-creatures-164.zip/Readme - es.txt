Mo Creatures [1.6.4]
------------------------------------------------------------------------------------------------
Mo'creatures mod para Minecraft 1.6.4 que añade al juego nuevos y geniales de animales y criaturas. 

Descarga y la velocidad de la mod Mo Criaturas para Minecraft 1.6.4 por favor haga clic en los enlaces de abajo de la página.

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.worldofmods.net

Permanent enlace a modification`s página: https://www.worldofmods.net/minecraft/mods/4582-mo-creatures-164.html

Compruebe nuestra sociales groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods