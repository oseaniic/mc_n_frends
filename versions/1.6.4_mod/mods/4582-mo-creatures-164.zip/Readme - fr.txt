Mo Creatures [1.6.4]
------------------------------------------------------------------------------------------------
Mo'creatures mod pour Minecraft 1.6.4 qui ajoute à votre jeu cool de nouveaux animaux et de créatures. 

Le téléchargement et le taux le mod Mo'Creatures pour Minecraft 1.6.4 veuillez cliquer sur les liens ci-dessous sur la page.

################################################################################################

INSTRUCTIONS D'INSTALLATION
------------------------------------------------------------------------------------------------
1. La copie des fichiers

(!) Ne pas oublier de faire des copies de l'original remplacés fichiers pour être en mesure de retirer la modification!

Copiez tout le contenu du dossier "00 - Copy to game folder" dans le dossier où le jeu est installé. Confirmer le remplacement.

################################################################################################

Cette modification a été téléchargé à partir de www.worldofmods.eu

Permanent lien vers modification`s page: https://www.worldofmods.eu/fr/minecraft/mods/4582-mo-creatures-164.html

Vérifier notre sociale groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods