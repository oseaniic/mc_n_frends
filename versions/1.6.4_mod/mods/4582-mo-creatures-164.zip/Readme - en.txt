Mo Creatures [1.6.4]
------------------------------------------------------------------------------------------------
Mo'creatures mod for Minecraft 1.6.4 that adds to your game cool new animals and creatures. 

Download and rate the mod Mo Creatures for Minecraft 1.6.4 please click on the links below on the page.

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.worldofmods.com

Permanent link to modification`s page: https://www.worldofmods.com/minecraft/mods/4582-mo-creatures-164.html

Check out our social groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods