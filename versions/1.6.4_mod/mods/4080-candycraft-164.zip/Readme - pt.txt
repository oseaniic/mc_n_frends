CandyCraft [1.6.4]
------------------------------------------------------------------------------------------------
CandyCraft mod para o jogo Minecraft, vai adicionar doces inimigos, novos blocos de doces, comida nova e armaduras com armas. 

Faça o Download e ler o CandyCraft mod do jogo Minecraft usando os links fornecidos abaixo na página.

################################################################################################

INSTRUÇÕES DE INSTALAÇÃO
------------------------------------------------------------------------------------------------
1. Cópia de arquivo

(!) Não se esqueça de fazer cópias do original arquivos substituídos para ser capaz de remover a modificação!

Copie todo o conteúdo da pasta "00 - Copy to game folder" para a pasta onde o jogo está instalado. Confirmar a substituição.

################################################################################################

Esta modificação foi baixado www.worldofmods.org

Permanent link para modification`s página: https://www.worldofmods.org/minecraft/mods/4080-candycraft-164.html

Check a nossa sociais groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods