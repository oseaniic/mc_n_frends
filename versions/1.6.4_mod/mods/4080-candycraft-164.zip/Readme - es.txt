CandyCraft [1.6.4]
------------------------------------------------------------------------------------------------
CandyCraft mod para el juego de Minecraft, agregar el caramelo enemigos, nuevos bloques de caramelo, nuevos alimentos y armaduras con las armas. 

Descargar y leer el CandyCraft mod para el juego de Minecraft utilizando los enlaces que se proporcionan a continuación en la página.

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.worldofmods.net

Permanent enlace a modification`s página: https://www.worldofmods.net/minecraft/mods/4080-candycraft-164.html

Compruebe nuestra sociales groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods