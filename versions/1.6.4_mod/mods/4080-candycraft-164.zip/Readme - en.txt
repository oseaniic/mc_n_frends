CandyCraft [1.6.4]
------------------------------------------------------------------------------------------------
CandyCraft mod for the game Minecraft, will add candy enemies, new candy blocks, new food and armor with weapons. 

Download and read the CandyCraft mod for the game Minecraft using the links provided below on the page.

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.worldofmods.com

Permanent link to modification`s page: https://www.worldofmods.com/minecraft/mods/4080-candycraft-164.html

Check out our social groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods