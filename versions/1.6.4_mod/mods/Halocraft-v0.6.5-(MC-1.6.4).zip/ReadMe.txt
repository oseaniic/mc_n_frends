Halocraft v0.6.5 for Minecraft 1.6.4

by  KILLER CHIEF, Camo7, Hellcraftjz, The Micahel, Brenwwe



This mod requires MC Forge for Minecraft 1.6.4:
------------------------------------------------------------------------------------------------------------------------------------------=
http://adf.ly/673885/http://files.minecraftforge.net/maven/net/minecraftforge/forge/1.6.4-9.11.1.965/forge-1.6.4-9.11.1.965-installer.jar =
or                                                                                                                                        =
http://files.minecraftforge.net/                                                                                                          =
------------------------------------------------------------------------------------------------------------------------------------------=



Installation:

www.killerchief.net/

=====================================Installing Minecraft Forge for Minecraft 1.6.4======================================
-Run Minecraft 1.6.4 at least once!                                                                                     =
-Go to the link above and download the Minecraft Forge installer to your computer.                                      =
-Open it by double clicking or open it with Java from right click menu,                                                 =
 (if it doesn't work you might need to install the Java Runtime Environment or Development Kit).                        =
-Select Install Client and make sure it shows the correct location for your Minecraft install directory,                =
 e.g. "C:\Users\Username\AppData\Roaming\.minecraft" and then press OK.                                                 =
-With any luck that will succeed!                                                                                       =
-Now close that window and open Minecraft.                                                                              =
-Create a new 'Profile' and name it something sensible,                                                                 =
 (i like to call mine "1.6.4-Forge9.11.1.965" because it matches the version and Forge type so you don't get mixed up). =
-then check "Game Directory" and enter something like,                                                                  =
 "C:\Users\Username\AppData\Roaming\.minecraft\_1.6.4-Forge9.11.1.965".                                                 =
 I call the folder this ("_1.6.4-Forge9.11.1.965") because that is where the game saves and stuff are,                  =
 so I can separate different versions etc.                                                                              =
-Then go down to "Use Version" and select "release 1.6.4-Forge9.11.1.965".                                              =
-Now customise and save the new Profile and select it from the menu at the bottom left of the Minecraft Launcher window.=
-And run at least Once!         ----You have now successfully installed Minecraft Forge!----                            =
------------------------------------------------------------------------------------------------------------------------=

=======================================Installing Halocraft v0.6.5========================================
                                                                                                         =
-Download the Recommended Version of Minecraft Forge for MC 1.6.4 and Install that FIRST!                =
-Successfully run Minecraft 1.6.4 with Forge Installed at least ONCE!                                    =
-Go to your .minecraft directory and navigate to the folder where you have MC Forge for 1.6.4 set up.    =
-Find the folder called "mods" (in the same directory as the saves, stats, resourcepacks and config are) =
 Then move "Halocraft v0.6.5 (MC 1.6.4).zip" (where this read me is located) into that mods folder.      =
-Run Minecraft (and select the correct 'Profile') and it should work!                                    =
                                                                                                         =
----Enjoy and Have lots of Fun!-----                                                                     =
                                                                                                         =
---------------------------------------------------------------------------------------------------------=




Report bugs and problems at:
-------------------------------------------------------------------------------------------------------=
Forum: http://www.minecraftforum.net/topic/758880-halocraft/                                           =
                                                                                                       =
ABSOLUTELY NO posting about requesting this mod to be updated!                                         =
-------------------------------------------------------------------------------------------------------=



Halo � Microsoft Corporation.
Halocraft was created under Microsoft's "Game Content Usage Rules" using assets from Halo.
It is not endorsed by Microsoft and does not reflect the views or opinions of Microsoft or anyone officially involved in producing or managing Halo.
As such, it does not contribute to the official narrative of the fictional universe, if applicable.

Game Content Usage Rules:
http://www.xbox.com/en-US/community/developer/rules
