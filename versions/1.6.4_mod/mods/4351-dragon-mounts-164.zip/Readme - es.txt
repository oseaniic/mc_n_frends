Dragon Mounts [1.6.4]
------------------------------------------------------------------------------------------------
Dragon Mounts mod para Minecraft 1.6.4 que añade en su juego el dragón negro territorio. 

Descargar e instalar Dragon Mounts mod para Minecraft 1.6.4 por favor haga clic en los enlaces situados debajo de la descripción.

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.worldofmods.net

Permanent enlace a modification`s página: https://www.worldofmods.net/minecraft/mods/4351-dragon-mounts-164.html

Compruebe nuestra sociales groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods