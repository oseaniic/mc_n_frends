Dragon Mounts [1.6.4]
------------------------------------------------------------------------------------------------
Dragon Monte mod pour Minecraft 1.6.4 qui ajoute dans votre jeu le dragon noir territoire. 

Télécharger et installer Dragon Monte mod pour Minecraft 1.6.4 veuillez cliquer sur les liens situés en dessous de la description.

################################################################################################

INSTRUCTIONS D'INSTALLATION
------------------------------------------------------------------------------------------------
1. La copie des fichiers

(!) Ne pas oublier de faire des copies de l'original remplacés fichiers pour être en mesure de retirer la modification!

Copiez tout le contenu du dossier "00 - Copy to game folder" dans le dossier où le jeu est installé. Confirmer le remplacement.

################################################################################################

Cette modification a été téléchargé à partir de www.worldofmods.eu

Permanent lien vers modification`s page: https://www.worldofmods.eu/fr/minecraft/mods/4351-dragon-mounts-164.html

Vérifier notre sociale groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods