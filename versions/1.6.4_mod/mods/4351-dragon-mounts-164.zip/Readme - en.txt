Dragon Mounts [1.6.4]
------------------------------------------------------------------------------------------------
Dragon Mounts mod for Minecraft 1.6.4 that adds in your game the black dragon territory. 

Download and install Dragon Mounts mod for Minecraft 1.6.4 please click on the links located below the description.

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.worldofmods.com

Permanent link to modification`s page: https://www.worldofmods.com/minecraft/mods/4351-dragon-mounts-164.html

Check out our social groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods