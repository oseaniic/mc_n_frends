Dragon Mounts [1.6.4]
------------------------------------------------------------------------------------------------
Dragon Mounts mod für Minecraft 1.6.4 fügt hinzu, dass in Ihrem Spiel der schwarze Drache-Gebiet. 

Herunterladen und installieren Dragon Mounts mod für Minecraft 1.6.4 bitte klicken Sie auf die links, die sich unter der Beschreibung.

################################################################################################

EINBAUANLEITUNG
------------------------------------------------------------------------------------------------
1. Kopieren von Dateien

(!) Vergessen Sie nicht, machen Kopien des Originals ersetzt Dateien in der Lage sein, um die Änderung zu entfernen!

Kopieren Sie den gesamten Inhalt des Ordners "00 - Copy to game folder" auf den Ordner, in dem das Spiel installiert ist. Bestätigen Sie den Ersatz.

################################################################################################

Diese Modifikation wurde von www.worldofmods.eu heruntergeladen wurden
Permanent Link zu Seite modification`s: https://www.worldofmods.eu/de/minecraft/mods/4351-dragon-mounts-164.html

Überprüfen unsere sozialen groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods