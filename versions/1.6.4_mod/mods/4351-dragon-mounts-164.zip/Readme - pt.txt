Dragon Mounts [1.6.4]
------------------------------------------------------------------------------------------------
Dragão Monta mod para Minecraft 1.6.4 que adiciona no seu jogo, o dragão negro território. 

Baixar e instalar o Dragão Monta mod para Minecraft 1.6.4 por favor clique nos links localizados abaixo da descrição.

################################################################################################

INSTRUÇÕES DE INSTALAÇÃO
------------------------------------------------------------------------------------------------
1. Cópia de arquivo

(!) Não se esqueça de fazer cópias do original arquivos substituídos para ser capaz de remover a modificação!

Copie todo o conteúdo da pasta "00 - Copy to game folder" para a pasta onde o jogo está instalado. Confirmar a substituição.

################################################################################################

Esta modificação foi baixado www.worldofmods.org

Permanent link para modification`s página: https://www.worldofmods.org/minecraft/mods/4351-dragon-mounts-164.html

Check a nossa sociais groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods