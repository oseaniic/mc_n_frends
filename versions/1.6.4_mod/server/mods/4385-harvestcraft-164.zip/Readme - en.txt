HarvestCraft [1.6.4]
------------------------------------------------------------------------------------------------
HarvestCraft mod for Minecraft will add in your gaming world, new plants, ornamental blocks, mechanisms and food. 

Download and read the HarvestCraft mod for Minecraft using the links below on the page.

################################################################################################

INSTALLATION INSTRUCTIONS
------------------------------------------------------------------------------------------------
1. File copying

(!) Do not forget to make copies of the original replaced files to be able to remove the modification!

Copy all the contents of the folder "00 - Copy to game folder" to the folder where the game is installed. Confirm the replacement.

################################################################################################

This modification has been downloaded from www.worldofmods.com

Permanent link to modification`s page: https://www.worldofmods.com/minecraft/mods/4385-harvestcraft-164.html

Check out our social groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods