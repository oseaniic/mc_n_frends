HarvestCraft [1.6.4]
------------------------------------------------------------------------------------------------
HarvestCraft mod para Minecraft va a añadir en su mundo de juegos, nuevas plantas, ornamentales bloques, los mecanismos y los alimentos. 

Descargar y leer el HarvestCraft mod para Minecraft utilizando los enlaces de abajo de la página.

################################################################################################

INSTRUCCIONES DE INSTALACIÓN
------------------------------------------------------------------------------------------------
1. La copia de archivos

(!) No se olvide de hacer copias de la original de los archivos reemplazados a ser capaz de eliminar la modificación!

Copie todo el contenido de la carpeta "00 - Copy to game folder" a la carpeta donde está instalado el juego. Confirmar el reemplazo.

################################################################################################

Esta modificación ha sido descargado de www.worldofmods.net

Permanent enlace a modification`s página: https://www.worldofmods.net/minecraft/mods/4385-harvestcraft-164.html

Compruebe nuestra sociales groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods