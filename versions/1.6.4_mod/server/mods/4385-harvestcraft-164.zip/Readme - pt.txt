HarvestCraft [1.6.4]
------------------------------------------------------------------------------------------------
HarvestCraft mod para Minecraft irá adicionar no mundo dos jogos, novas plantas, ornamentais blocos, de mecanismos e de alimentos. 

Faça o Download e ler o HarvestCraft mod para Minecraft usando os links abaixo na página.

################################################################################################

INSTRUÇÕES DE INSTALAÇÃO
------------------------------------------------------------------------------------------------
1. Cópia de arquivo

(!) Não se esqueça de fazer cópias do original arquivos substituídos para ser capaz de remover a modificação!

Copie todo o conteúdo da pasta "00 - Copy to game folder" para a pasta onde o jogo está instalado. Confirmar a substituição.

################################################################################################

Esta modificação foi baixado www.worldofmods.org

Permanent link para modification`s página: https://www.worldofmods.org/minecraft/mods/4385-harvestcraft-164.html

Check a nossa sociais groups!
http://vk.com/worldofmodscom
https://twitter.com/worldofmodscom
https://www.facebook.com/worldofmodscom
https://www.youtube.com/worldofmods